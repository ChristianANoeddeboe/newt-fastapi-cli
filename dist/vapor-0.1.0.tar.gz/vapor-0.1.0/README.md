# Vapor CLI

Used to automate boiler plate creation